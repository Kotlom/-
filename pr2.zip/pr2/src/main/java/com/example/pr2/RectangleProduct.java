package com.example.pr2;

import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Rectangle;
import javafx.scene.paint.Color;

public class RectangleProduct implements ShapeProduct {
    @Override
    public void setup(AnchorPane pane, double x, double y, Paint color, double strokeWidth, HelloController controller) {
        Rectangle rect = new Rectangle(x, y, 20, 20);
        rect.setFill(color);
        rect.setStroke(Color.BLACK);
        rect.setStrokeWidth(strokeWidth);
        rect.setOnScroll(controller::OnScroll);
        rect.setOnMouseMoved(controller::MouseMoved);
        rect.setOnMouseExited(controller::OnMouseExited);
        pane.getChildren().add(rect);
        controller.setRECTANGLE(rect);
    }
}