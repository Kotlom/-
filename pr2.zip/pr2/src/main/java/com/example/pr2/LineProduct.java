package com.example.pr2;

import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Line;

public class LineProduct implements ShapeProduct {
    @Override
    public void setup(AnchorPane pane, double x, double y, Paint color, double strokeWidth, HelloController controller) {
        Line line = new Line(x, y, x + 1, y + 1);
        line.setStroke(color);
        line.setStrokeWidth(strokeWidth);
        line.setOnMousePressed(controller::LineMousePressed);
        line.setOnMouseDragged(controller::LineMouseDragged);
        line.setOnScroll(controller::OnScroll);
        pane.getChildren().add(line);
        controller.setLINE(line);
    }
}