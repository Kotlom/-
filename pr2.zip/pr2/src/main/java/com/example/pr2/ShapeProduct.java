package com.example.pr2;

import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Paint;

public interface ShapeProduct {
    // 1: панель, 2-3: координаты, 4: цвет, 5: толщина, 6: контроллер для событий
    void setup(AnchorPane pane, double x, double y, Paint color, double strokeWidth, HelloController controller);
}