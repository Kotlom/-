package com.example.pr2;

import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Circle;

public class CircleProduct implements ShapeProduct {
    @Override
    public void setup(AnchorPane pane, double x, double y, Paint color, double strokeWidth, HelloController controller) {
        Circle circle = new Circle(x, y, 0);
        circle.setFill(color);
        circle.setOnScroll(controller::OnScroll);
        circle.setOnMouseClicked(controller::OnMouseClicked);

        pane.getChildren().add(circle);

        // ВАЖНО: передаем ссылку назад в контроллер, чтобы работал panedragged
        controller.setCIRCLE(circle);
    }
}